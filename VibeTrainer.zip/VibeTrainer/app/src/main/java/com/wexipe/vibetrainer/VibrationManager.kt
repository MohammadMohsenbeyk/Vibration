package com.wexipe.vibetrainer

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log

/**
 * All vibration hardware interaction lives here so scheduling/UI code never has to think
 * about API-level differences or missing hardware.
 */
object VibrationManager {

    private const val TAG = "VibeTrainer.Vibration"

    fun getVibrator(context: Context): Vibrator {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val manager =
                context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            manager.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
    }

    fun hasVibrator(context: Context): Boolean {
        return try {
            getVibrator(context).hasVibrator()
        } catch (e: Exception) {
            Log.w(TAG, "hasVibrator check failed", e)
            false
        }
    }

    fun hasAmplitudeControl(context: Context): Boolean {
        return try {
            getVibrator(context).hasAmplitudeControl()
        } catch (e: Exception) {
            Log.w(TAG, "hasAmplitudeControl check failed", e)
            false
        }
    }

    /**
     * Builds a "heavy, repeated pulses" waveform: on-off-on-off..., ending on an "on"
     * segment. All inputs are re-clamped here (defense in depth even if Settings already
     * clamped them) and the total duration is hard-capped so the motor is never driven in
     * one very long uninterrupted burst.
     */
    fun buildPattern(
        context: Context,
        vibrationDurationMs: Long,
        pauseDurationMs: Long,
        repeatCount: Int,
        amplitude: Int
    ): VibrationEffect {
        val pulseMs = VibeSettings.clampVibrationMs(vibrationDurationMs)
        val pauseMs = VibeSettings.clampPauseMs(pauseDurationMs)
        var repeat = VibeSettings.clampRepeatCount(repeatCount)

        // Shrink the repeat count (never the pulse itself) until the whole pattern fits
        // under the hard cap.
        while (repeat > 1 &&
            (repeat * pulseMs + (repeat - 1) * pauseMs) > VibeSettings.MAX_TOTAL_PATTERN_MS
        ) {
            repeat--
        }

        val amp = VibeSettings.clampAmplitude(amplitude)
        val supportsAmplitude = hasAmplitudeControl(context)

        val segmentCount = repeat * 2 - 1 // pulses + gaps between them, no trailing gap
        val timings = LongArray(segmentCount)
        val amplitudes = IntArray(segmentCount)

        for (i in 0 until repeat) {
            val pulseIndex = i * 2
            timings[pulseIndex] = pulseMs
            amplitudes[pulseIndex] =
                if (supportsAmplitude) amp else VibrationEffect.DEFAULT_AMPLITUDE
            if (i < repeat - 1) {
                val gapIndex = pulseIndex + 1
                timings[gapIndex] = pauseMs
                amplitudes[gapIndex] = 0
            }
        }

        return VibrationEffect.createWaveform(timings, amplitudes, -1)
    }

    /**
     * Runs the pattern immediately. Never throws - any hardware/OS error is caught and
     * logged so a bad vibration attempt can never crash the receiver or the app.
     */
    fun runPattern(
        context: Context,
        vibrationDurationMs: Long,
        pauseDurationMs: Long,
        repeatCount: Int,
        amplitude: Int
    ): Boolean {
        if (!hasVibrator(context)) {
            Log.w(TAG, "Device reports no vibrator hardware, skipping run")
            return false
        }
        return try {
            val effect = buildPattern(
                context,
                vibrationDurationMs,
                pauseDurationMs,
                repeatCount,
                amplitude
            )
            val vibrator = getVibrator(context)
            vibrator.cancel()
            vibrator.vibrate(effect)
            Log.d(TAG, "Pattern started: pulses=$repeatCount amplitude=$amplitude")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to run vibration pattern", e)
            false
        }
    }
}
