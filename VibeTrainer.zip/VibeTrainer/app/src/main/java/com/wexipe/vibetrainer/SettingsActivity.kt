package com.wexipe.vibetrainer

import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.wexipe.vibetrainer.ui.components.ChipRow
import com.wexipe.vibetrainer.ui.components.LabeledRow
import com.wexipe.vibetrainer.ui.components.SectionCard
import com.wexipe.vibetrainer.ui.components.StatusChip
import com.wexipe.vibetrainer.ui.components.StatusLevel
import com.wexipe.vibetrainer.ui.theme.Dimens
import com.wexipe.vibetrainer.ui.theme.LocalVibeExtraColors
import com.wexipe.vibetrainer.ui.theme.VibeTrainerTheme
import kotlinx.coroutines.launch

class SettingsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var settings by remember { mutableStateOf(VibeSettings()) }
            LaunchedEffect(Unit) {
                PrefsManager.flow(this@SettingsActivity).collect { settings = it }
            }
            VibeTrainerTheme(themeMode = settings.themeMode) {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    SettingsScreen(currentThemeMode = settings.themeMode, onBack = { finish() })
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(currentThemeMode: ThemeMode, onBack: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()

    var startMinutes by remember { mutableStateOf(VibeSettings.DEFAULT_START_MINUTES) }
    var endMinutes by remember { mutableStateOf(VibeSettings.DEFAULT_END_MINUTES) }
    var intervalMinutes by remember { mutableStateOf(VibeSettings.DEFAULT_INTERVAL_MINUTES) }
    var customIntervalMode by remember { mutableStateOf(false) }
    var vibrationMs by remember { mutableStateOf(VibeSettings.DEFAULT_VIBRATION_MS) }
    var pauseMs by remember { mutableStateOf(VibeSettings.DEFAULT_PAUSE_MS) }
    var repeatCount by remember { mutableStateOf(VibeSettings.DEFAULT_REPEAT_COUNT) }
    var amplitude by remember { mutableStateOf(VibeSettings.DEFAULT_AMPLITUDE) }
    var enabled by remember { mutableStateOf(false) }
    var saved by remember { mutableStateOf(false) }
    var statusRefresh by remember { mutableStateOf(0) }
    val lifecycleOwner = androidx.compose.ui.platform.LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) {
                statusRefresh++
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    LaunchedEffect(Unit) {
        val s = PrefsManager.snapshot(context)
        startMinutes = s.startMinutes
        endMinutes = s.endMinutes
        intervalMinutes = s.intervalMinutes
        customIntervalMode = s.intervalMinutes !in listOf(
            VibeSettings.INTERVAL_PRESET_10H, VibeSettings.INTERVAL_PRESET_12H,
            VibeSettings.INTERVAL_PRESET_20H, VibeSettings.INTERVAL_PRESET_24H
        )
        vibrationMs = s.vibrationDurationMs
        pauseMs = s.pauseDurationMs
        repeatCount = s.repeatCount
        amplitude = s.amplitude
        enabled = s.enabled
    }

    val supportsAmplitude = remember { VibrationManager.hasAmplitudeControl(context) }
    val hasVibrator = remember(statusRefresh) { VibrationManager.hasVibrator(context) }
    val canExact = remember(statusRefresh) { AlarmScheduler.canScheduleExact(context) }
    val ignoringBattery = remember(statusRefresh) { StatusUtils.isIgnoringBatteryOptimizations(context) }
    val totalPatternMs = VibrationManager.totalDurationMs(vibrationMs, pauseMs, repeatCount)

    suspend fun saveAndReschedule() {
        // Note: VibrationService captures pattern parameters via Intent extras at the
        // moment it starts, not by re-reading these settings live - so saving new values
        // here can never disturb a pattern that is already running; only the NEXT run
        // (automatic or manual test) uses the values saved below.
        PrefsManager.saveScheduleSettings(context, startMinutes, endMinutes)
        PrefsManager.saveIntervalMinutes(context, intervalMinutes)
        PrefsManager.savePatternSettings(context, vibrationMs, pauseMs, repeatCount, amplitude)
        if (enabled) {
            val fresh = PrefsManager.snapshot(context)
            val next = AlarmScheduler.computeNextTrigger(
                System.currentTimeMillis(), fresh.intervalMinutes, fresh.startMinutes, fresh.endMinutes, isInitial = true
            )
            AlarmScheduler.scheduleAt(context, next)
            PrefsManager.setNextAlarmTime(context, next)
        }
        saved = true
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text("تنظیمات") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = Dimens.spaceMd)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(Dimens.spaceMd)
        ) {

            // ---- 1. زمان‌بندی ----
            SectionCard(title = "زمان‌بندی", subtitle = "بازه‌ای از شبانه‌روز که اجرا مجاز است") {
                LabeledRow("ساعت شروع", StatusUtils.formatMinutesOfDay(startMinutes))
                Slider(
                    value = startMinutes.toFloat(),
                    onValueChange = { startMinutes = it.toInt().coerceIn(0, endMinutes) },
                    valueRange = 0f..(23f * 60f + 59f)
                )
                LabeledRow("ساعت پایان", StatusUtils.formatMinutesOfDay(endMinutes))
                Slider(
                    value = endMinutes.toFloat(),
                    onValueChange = { endMinutes = it.toInt().coerceIn(startMinutes, 23 * 60 + 59) },
                    valueRange = 0f..(23f * 60f + 59f)
                )
            }

            // ---- 2. فاصله اجرای ویبره (جدا از بازه مجاز) ----
            SectionCard(
                title = "فاصله اجرای ویبره",
                subtitle = "چند وقت یک‌بار اجرا شود - مستقل از «بازه مجاز» بالا"
            ) {
                ChipRow {
                    IntervalPresetChip("۱۰ ساعت", VibeSettings.INTERVAL_PRESET_10H, intervalMinutes, customIntervalMode) {
                        intervalMinutes = it; customIntervalMode = false
                    }
                    IntervalPresetChip("۱۲ ساعت", VibeSettings.INTERVAL_PRESET_12H, intervalMinutes, customIntervalMode) {
                        intervalMinutes = it; customIntervalMode = false
                    }
                    IntervalPresetChip("۲۰ ساعت", VibeSettings.INTERVAL_PRESET_20H, intervalMinutes, customIntervalMode) {
                        intervalMinutes = it; customIntervalMode = false
                    }
                    IntervalPresetChip("۲۴ ساعت", VibeSettings.INTERVAL_PRESET_24H, intervalMinutes, customIntervalMode) {
                        intervalMinutes = it; customIntervalMode = false
                    }
                    FilterChip(
                        selected = customIntervalMode,
                        onClick = { customIntervalMode = true },
                        label = { Text("سفارشی") }
                    )
                }
                AnimatedVisibility(visible = customIntervalMode) {
                    Column {
                        LabeledRow("فاصله سفارشی", StatusUtils.formatIntervalLabel(intervalMinutes))
                        Slider(
                            value = intervalMinutes.toFloat(),
                            onValueChange = { intervalMinutes = VibeSettings.clampIntervalMinutes(it.toInt()) },
                            valueRange = VibeSettings.MIN_INTERVAL_MINUTES.toFloat()..VibeSettings.MAX_INTERVAL_MINUTES.toFloat()
                        )
                    }
                }
                if (!customIntervalMode) {
                    Text(
                        "انتخاب فعلی: ${StatusUtils.formatIntervalLabel(intervalMinutes)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = LocalVibeExtraColors.current.textSecondary
                    )
                }
            }

            // ---- 3. الگوی ویبره ----
            SectionCard(title = "الگوی ویبره") {
                LabeledRow("مدت هر ویبره", "${StatusUtils.toPersianDigits(vibrationMs.toString())} میلی‌ثانیه")
                Slider(
                    value = vibrationMs.toFloat(),
                    onValueChange = { vibrationMs = it.toLong() },
                    valueRange = VibeSettings.MIN_PULSE_MS.toFloat()..VibeSettings.MAX_PULSE_MS.toFloat()
                )

                LabeledRow("فاصله بین ویبره‌ها", "${StatusUtils.toPersianDigits(pauseMs.toString())} میلی‌ثانیه")
                Slider(
                    value = pauseMs.toFloat(),
                    onValueChange = { pauseMs = it.toLong() },
                    valueRange = VibeSettings.MIN_PAUSE_MS.toFloat()..VibeSettings.MAX_PAUSE_MS.toFloat()
                )

                LabeledRow("تعداد تکرار", "${StatusUtils.toPersianDigits(repeatCount.toString())} بار")
                Slider(
                    value = repeatCount.toFloat(),
                    onValueChange = { repeatCount = it.toInt() },
                    valueRange = VibeSettings.MIN_REPEAT_COUNT.toFloat()..VibeSettings.MAX_REPEAT_COUNT.toFloat(),
                    steps = VibeSettings.MAX_REPEAT_COUNT - VibeSettings.MIN_REPEAT_COUNT - 1
                )

                if (supportsAmplitude) {
                    LabeledRow("شدت ویبره", "${StatusUtils.toPersianDigits(amplitude.toString())} از ۲۵۵")
                    Slider(
                        value = amplitude.toFloat(),
                        onValueChange = { amplitude = it.toInt() },
                        valueRange = VibeSettings.MIN_AMPLITUDE.toFloat()..VibeSettings.MAX_AMPLITUDE.toFloat()
                    )
                } else {
                    Text(
                        "این دستگاه از کنترل شدت ویبره پشتیبانی نمی‌کند؛ ویبره با شدت پیش‌فرض دستگاه اجرا می‌شود.",
                        style = MaterialTheme.typography.bodySmall,
                        color = LocalVibeExtraColors.current.textSecondary
                    )
                }

                LabeledRow("مدت کل تقریبی", StatusUtils.formatPatternDuration(totalPatternMs))

                OutlinedButton(
                    onClick = {
                        VibrationService.startTest(context, vibrationMs, pauseMs, repeatCount, amplitude)
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("امتحان همین الگو")
                }
            }

            // ---- 4. رفتار برنامه ----
            SectionCard(title = "رفتار برنامه", subtitle = "ظاهر برنامه") {
                ChipRow {
                    ThemeModeChip("روشن", ThemeMode.LIGHT, currentThemeMode) {
                        scope.launch { PrefsManager.setThemeMode(context, it) }
                    }
                    ThemeModeChip("تیره", ThemeMode.DARK, currentThemeMode) {
                        scope.launch { PrefsManager.setThemeMode(context, it) }
                    }
                    ThemeModeChip("سیستم", ThemeMode.SYSTEM, currentThemeMode) {
                        scope.launch { PrefsManager.setThemeMode(context, it) }
                    }
                }
            }

            // ---- 5. وضعیت و دسترسی‌های سیستم ----
            SectionCard(title = "وضعیت و دسترسی‌های سیستم") {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("قابلیت ویبره", style = MaterialTheme.typography.bodyMedium, color = LocalVibeExtraColors.current.textSecondary)
                    StatusChip(
                        text = if (hasVibrator) "آماده" else "بدون موتور ویبره",
                        level = if (hasVibrator) StatusLevel.SUCCESS else StatusLevel.ERROR
                    )
                }

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("زمان‌بندی دقیق", style = MaterialTheme.typography.bodyMedium, color = LocalVibeExtraColors.current.textSecondary)
                    StatusChip(
                        text = if (canExact) "آماده" else "نیاز به اقدام",
                        level = if (canExact) StatusLevel.SUCCESS else StatusLevel.WARNING
                    )
                }
                if (!canExact && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    OutlinedButton(onClick = { AlarmScheduler.openExactAlarmSettings(context) }, modifier = Modifier.fillMaxWidth()) {
                        Text("باز کردن تنظیمات Exact Alarm")
                    }
                }

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("بهینه‌سازی باتری", style = MaterialTheme.typography.bodyMedium, color = LocalVibeExtraColors.current.textSecondary)
                    StatusChip(
                        text = if (ignoringBattery) "مستثناست" else "ممکن است تأخیر بدهد",
                        level = if (ignoringBattery) StatusLevel.SUCCESS else StatusLevel.WARNING
                    )
                }
                if (!ignoringBattery) {
                    OutlinedButton(onClick = { StatusUtils.requestIgnoreBatteryOptimizations(context) }, modifier = Modifier.fillMaxWidth()) {
                        Text("درخواست معافیت از بهینه‌سازی باتری")
                    }
                }

                Text(
                    "در برخی گوشی‌های سامسونگ، مدیریت پس‌زمینهٔ اختصاصی سامسونگ می‌تواند مستقل از این تنظیمات اجرا را به تأخیر بیندازد. در صورت بروز تأخیر، برنامه را در تنظیمات باتری گوشی روی «بدون محدودیت» قرار دهید.",
                    style = MaterialTheme.typography.bodySmall,
                    color = LocalVibeExtraColors.current.textSecondary
                )
            }

            Button(
                onClick = { scope.launch { saveAndReschedule() } },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("ذخیره تغییرات")
            }

            AnimatedVisibility(visible = saved) {
                Text("تنظیمات ذخیره شد.", color = LocalVibeExtraColors.current.success)
            }

            androidx.compose.foundation.layout.Spacer(Modifier.height(Dimens.spaceLg))
        }
    }
}

@Composable
private fun IntervalPresetChip(
    label: String,
    valueMinutes: Int,
    currentMinutes: Int,
    customMode: Boolean,
    onSelected: (Int) -> Unit
) {
    FilterChip(
        selected = !customMode && currentMinutes == valueMinutes,
        onClick = { onSelected(valueMinutes) },
        label = { Text(label) }
    )
}

@Composable
private fun ThemeModeChip(label: String, mode: ThemeMode, current: ThemeMode, onSelected: (ThemeMode) -> Unit) {
    FilterChip(
        selected = current == mode,
        onClick = { onSelected(mode) },
        label = { Text(label) }
    )
}
