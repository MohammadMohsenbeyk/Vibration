package com.wexipe.vibetrainer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.wexipe.vibetrainer.ui.theme.VibeTrainerTheme
import kotlinx.coroutines.launch

class SettingsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            VibeTrainerTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    SettingsScreen(onBack = { finish() })
                }
            }
        }
    }
}

private fun minutesToLabel(m: Int): String {
    val h = m / 60
    val mm = m % 60
    return "%02d:%02d".format(h, mm)
}

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()

    var startMinutes by remember { mutableStateOf(VibeSettings.DEFAULT_START_MINUTES) }
    var endMinutes by remember { mutableStateOf(VibeSettings.DEFAULT_END_MINUTES) }
    var vibrationMs by remember { mutableStateOf(VibeSettings.DEFAULT_VIBRATION_MS) }
    var pauseMs by remember { mutableStateOf(VibeSettings.DEFAULT_PAUSE_MS) }
    var repeatCount by remember { mutableStateOf(VibeSettings.DEFAULT_REPEAT_COUNT) }
    var amplitude by remember { mutableStateOf(VibeSettings.DEFAULT_AMPLITUDE) }
    var enabled by remember { mutableStateOf(false) }
    var saved by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val s = PrefsManager.snapshot(context)
        startMinutes = s.startMinutes
        endMinutes = s.endMinutes
        vibrationMs = s.vibrationDurationMs
        pauseMs = s.pauseDurationMs
        repeatCount = s.repeatCount
        amplitude = s.amplitude
        enabled = s.enabled
    }

    val supportsAmplitude = remember { VibrationManager.hasAmplitudeControl(context) }
    val totalMs = repeatCount * vibrationMs + (repeatCount - 1).coerceAtLeast(0) * pauseMs

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("تنظیمات") })
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {

            SectionCard(title = "بازه مجاز اجرای روزانه") {
                LabeledValue("ساعت شروع", minutesToLabel(startMinutes))
                Slider(
                    value = startMinutes.toFloat(),
                    onValueChange = { startMinutes = it.toInt().coerceIn(0, endMinutes) },
                    valueRange = 0f..(23f * 60f + 59f)
                )
                LabeledValue("ساعت پایان", minutesToLabel(endMinutes))
                Slider(
                    value = endMinutes.toFloat(),
                    onValueChange = { endMinutes = it.toInt().coerceIn(startMinutes, 23 * 60 + 59) },
                    valueRange = 0f..(23f * 60f + 59f)
                )
                Text(
                    "هر روز یک زمان تصادفی بین این دو ساعت برای اجرای ویبره انتخاب می‌شود.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
            }

            SectionCard(title = "الگوی ویبره") {
                LabeledValue("مدت هر ویبره", "${vibrationMs} میلی‌ثانیه")
                Slider(
                    value = vibrationMs.toFloat(),
                    onValueChange = { vibrationMs = it.toLong() },
                    valueRange = VibeSettings.MIN_PULSE_MS.toFloat()..VibeSettings.MAX_PULSE_MS.toFloat()
                )

                LabeledValue("فاصله بین ویبره‌ها", "${pauseMs} میلی‌ثانیه")
                Slider(
                    value = pauseMs.toFloat(),
                    onValueChange = { pauseMs = it.toLong() },
                    valueRange = VibeSettings.MIN_PAUSE_MS.toFloat()..VibeSettings.MAX_PAUSE_MS.toFloat()
                )

                LabeledValue("تعداد تکرار", "$repeatCount بار")
                Slider(
                    value = repeatCount.toFloat(),
                    onValueChange = { repeatCount = it.toInt() },
                    valueRange = VibeSettings.MIN_REPEAT_COUNT.toFloat()..VibeSettings.MAX_REPEAT_COUNT.toFloat(),
                    steps = VibeSettings.MAX_REPEAT_COUNT - VibeSettings.MIN_REPEAT_COUNT - 1
                )

                if (supportsAmplitude) {
                    LabeledValue("شدت ویبره", "$amplitude از ۲۵۵")
                    Slider(
                        value = amplitude.toFloat(),
                        onValueChange = { amplitude = it.toInt() },
                        valueRange = VibeSettings.MIN_AMPLITUDE.toFloat()..VibeSettings.MAX_AMPLITUDE.toFloat()
                    )
                } else {
                    Text(
                        "این دستگاه از کنترل شدت ویبره پشتیبانی نمی‌کند؛ ویبره با شدت پیش‌فرض دستگاه اجرا می‌شود.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )
                }

                val cappedNote = if (totalMs > VibeSettings.MAX_TOTAL_PATTERN_MS) {
                    " (برای حفظ سلامت موتور، تعداد تکرار هنگام اجرا به‌صورت خودکار کاهش می‌یابد)"
                } else ""
                Text(
                    "مدت تقریبی کل عملیات: ${totalMs} میلی‌ثانیه$cappedNote",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
            }

            Button(onClick = {
                scope.launch {
                    PrefsManager.saveSettings(
                        context,
                        startMinutes,
                        endMinutes,
                        vibrationMs,
                        pauseMs,
                        repeatCount,
                        amplitude
                    )
                    // If the daily system is currently on, re-arm the alarm against the
                    // (possibly changed) time window right away instead of waiting for
                    // the next natural trigger.
                    if (enabled) {
                        val fresh = PrefsManager.snapshot(context)
                        val next = AlarmScheduler.computeNextTrigger(
                            System.currentTimeMillis(),
                            fresh.startMinutes,
                            fresh.endMinutes,
                            isInitial = true
                        )
                        AlarmScheduler.scheduleAt(context, next)
                        PrefsManager.setNextAlarmTime(context, next)
                    }
                    saved = true
                }
            }) {
                Text("ذخیره تنظیمات")
            }

            if (saved) {
                Text("تنظیمات ذخیره شد.", color = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            content()
        }
    }
}

@Composable
private fun LabeledValue(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodyLarge)
        Text(value, style = MaterialTheme.typography.labelLarge)
    }
}
