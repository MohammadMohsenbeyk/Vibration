package com.wexipe.vibetrainer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Runs one vibration pattern from start to finish, completely independent of any
 * Activity/Compose lifecycle.
 *
 * WHY THIS EXISTS: [Vibrator.vibrate] itself is fire-and-forget at the OS level, but the
 * vibration is tied to this app's process/UID. Before this class existed, the pattern was
 * kicked off either from [AlarmReceiver]'s short-lived broadcast process or from a
 * Composable's `rememberCoroutineScope` tied to [MainActivity]. Neither of those gives
 * Android a reason to keep the process alive for the ~1-15 seconds the pattern actually
 * needs - the OS is free to kill the process at any point once the receiver/coroutine that
 * *started* the vibration returns, silently cutting the pattern short (this is the root
 * cause the "vibration stops after 2-3 repeats" class of bugs comes from).
 *
 * A short-lived FOREGROUND service with a visible notification is the standard, documented
 * way to tell Android "keep this process alive, the user cares about this right now" - for
 * exactly the pattern's duration and not a moment longer. On Android 14+ this uses the
 * dedicated "shortService" foreground service type (hard-capped at 3 minutes by the OS,
 * far more than our ~15s max pattern), so it can never linger.
 */
class VibrationService : Service() {

    companion object {
        private const val TAG = "VibeTrainer.Service"
        private const val CHANNEL_ID = "vibration_running"
        private const val NOTIFICATION_ID = 7001

        private const val EXTRA_MODE = "mode"
        private const val EXTRA_VIBRATION_MS = "vibration_ms"
        private const val EXTRA_PAUSE_MS = "pause_ms"
        private const val EXTRA_REPEAT_COUNT = "repeat_count"
        private const val EXTRA_AMPLITUDE = "amplitude"

        const val MODE_AUTO = "auto"
        const val MODE_TEST = "test"

        // Purely observational: lets the UI show "test in progress" without the UI
        // owning any part of the vibration itself. The service never reads this back.
        private val _isRunning = MutableStateFlow(false)
        val isRunning = _isRunning.asStateFlow()

        // Guards scenario "two triggers arrive almost simultaneously" (e.g. a duplicate
        // alarm broadcast racing a manual test): only one pattern Job may be active at a
        // time, checked and set under the class lock in onStartCommand.
        @Volatile
        private var activeJob: Job? = null

        fun startAutomatic(
            context: Context,
            vibrationDurationMs: Long,
            pauseDurationMs: Long,
            repeatCount: Int,
            amplitude: Int
        ) = start(context, MODE_AUTO, vibrationDurationMs, pauseDurationMs, repeatCount, amplitude)

        fun startTest(
            context: Context,
            vibrationDurationMs: Long,
            pauseDurationMs: Long,
            repeatCount: Int,
            amplitude: Int
        ) = start(context, MODE_TEST, vibrationDurationMs, pauseDurationMs, repeatCount, amplitude)

        private fun start(
            context: Context,
            mode: String,
            vibrationDurationMs: Long,
            pauseDurationMs: Long,
            repeatCount: Int,
            amplitude: Int
        ) {
            val intent = Intent(context, VibrationService::class.java).apply {
                putExtra(EXTRA_MODE, mode)
                putExtra(EXTRA_VIBRATION_MS, vibrationDurationMs)
                putExtra(EXTRA_PAUSE_MS, pauseDurationMs)
                putExtra(EXTRA_REPEAT_COUNT, repeatCount)
                putExtra(EXTRA_AMPLITUDE, amplitude)
            }
            try {
                context.startForegroundService(intent)
            } catch (e: Exception) {
                // Extremely rare (e.g. OS-level FGS start restrictions). Logged only -
                // there is nothing else this call site can safely do about it.
                Log.e(TAG, "Failed to start VibrationService", e)
            }
        }
    }

    private val serviceScope = CoroutineScope(SupervisorJob())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) {
            stopSelf(startId)
            return START_NOT_STICKY
        }

        synchronized(VibrationService::class.java) {
            if (activeJob?.isActive == true) {
                // A pattern is already running - do not start a second overlapping one
                // and do not show a second notification. This is the "two triggers at
                // once" guard (in addition to the recent-run-gap duplicate guard already
                // done in AlarmReceiver before it ever gets here).
                Log.w(TAG, "Ignoring start request: a vibration is already running")
                stopSelf(startId)
                return START_NOT_STICKY
            }
        }

        val mode = intent.getStringExtra(EXTRA_MODE) ?: MODE_TEST
        val vibrationMs = intent.getLongExtra(EXTRA_VIBRATION_MS, VibeSettings.DEFAULT_VIBRATION_MS)
        val pauseMs = intent.getLongExtra(EXTRA_PAUSE_MS, VibeSettings.DEFAULT_PAUSE_MS)
        val repeatCount = intent.getIntExtra(EXTRA_REPEAT_COUNT, VibeSettings.DEFAULT_REPEAT_COUNT)
        val amplitude = intent.getIntExtra(EXTRA_AMPLITUDE, VibeSettings.DEFAULT_AMPLITUDE)

        // Notification is attempted first, but its success or failure never gates the
        // vibration below - a missing POST_NOTIFICATIONS grant must never stop the
        // actual pattern from running.
        showRunningNotification()
        _isRunning.value = true

        val job = serviceScope.launch {
            var error: Exception? = null
            try {
                val started = VibrationManager.runPattern(
                    this@VibrationService, vibrationMs, pauseMs, repeatCount, amplitude
                )
                val totalMs = VibrationManager.totalDurationMs(vibrationMs, pauseMs, repeatCount)
                if (started && totalMs > 0) {
                    // Vibrator.vibrate() already returned - the hardware is now vibrating
                    // on its own. We hold this foreground service (and its notification)
                    // alive for the pattern's real duration purely so the process is
                    // never a background-kill candidate before the pattern is actually
                    // done - this delay is the entire fix for the "cut short" problem.
                    delay(totalMs)
                }
            } catch (e: Exception) {
                error = e
                Log.e(TAG, "Vibration pattern failed", e)
            } finally {
                _isRunning.value = false
                try {
                    if (mode == MODE_AUTO) {
                        finishAutomaticRun(error)
                    } else {
                        PrefsManager.setLastTestTime(applicationContext, System.currentTimeMillis())
                    }
                } catch (e: Exception) {
                    // Never let a DataStore/scheduling failure prevent cleanup below.
                    Log.e(TAG, "Failed to record run result", e)
                }
                stopRunning(startId)
            }
        }
        synchronized(VibrationService::class.java) { activeJob = job }

        return START_NOT_STICKY
    }

    /**
     * Records the automatic run and arms the next cycle, exactly once the pattern has
     * truly finished (not when it started) - matching the required order: vibrate ->
     * notification -> full pattern -> remove notification -> record last run -> compute
     * next -> schedule next alarm. Any exception here is caught by the caller so it can
     * never block the notification/service cleanup that follows.
     */
    private suspend fun finishAutomaticRun(error: Exception?) {
        val now = System.currentTimeMillis()
        PrefsManager.setLastRunTime(applicationContext, now)

        val settings = PrefsManager.snapshot(applicationContext)
        // Documented decision (required by design): if the user switched the daily
        // system OFF while this vibration was running, settings.enabled is already
        // false here. We deliberately do NOT schedule a new alarm in that case - but we
        // also never touched/interrupted the vibration itself above, so a run already in
        // progress when the user disables the system is still allowed to finish.
        if (settings.enabled) {
            val next = AlarmScheduler.computeNextTrigger(
                now, settings.intervalMinutes, settings.startMinutes, settings.endMinutes, isInitial = false
            )
            AlarmScheduler.scheduleAt(applicationContext, next)
            PrefsManager.setNextAlarmTime(applicationContext, next)
        }
        if (error != null) {
            Log.w(TAG, "Automatic run finished with an error; next cycle handled above if still enabled", error)
        }
    }

    private fun stopRunning(startId: Int) {
        removeNotification()
        synchronized(VibrationService::class.java) { activeJob = null }
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf(startId)
    }

    override fun onDestroy() {
        serviceScope.cancel()
        _isRunning.value = false
        super.onDestroy()
    }

    private fun showRunningNotification() {
        try {
            val nm = getSystemService(NotificationManager::class.java) ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                if (nm.getNotificationChannel(CHANNEL_ID) == null) {
                    val channel = NotificationChannel(
                        CHANNEL_ID, "اجرای ویبره", NotificationManager.IMPORTANCE_LOW
                    ).apply {
                        description = "فقط در طول اجرای الگوی ویبره نمایش داده می‌شود"
                        // The channel itself must never vibrate - we already trigger the
                        // real pattern ourselves; a vibrating channel would silently
                        // double it.
                        enableVibration(false)
                        setSound(null, null)
                        enableLights(false)
                    }
                    nm.createNotificationChannel(channel)
                }
            }

            val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Vibration Starts")
                .setSmallIcon(R.drawable.ic_notification)
                .setOngoing(true)
                .setSilent(true)
                .setCategory(NotificationCompat.CATEGORY_STATUS)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build()

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                ServiceCompat.startForeground(
                    this,
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SHORT_SERVICE
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (e: Exception) {
            // Missing POST_NOTIFICATIONS (API 33+), a restricted OEM policy, or any other
            // notification failure must never stop the vibration below from running -
            // only the visible indicator is lost in that case.
            Log.w(TAG, "Could not show the running notification, continuing without it", e)
        }
    }

    private fun removeNotification() {
        try {
            getSystemService(NotificationManager::class.java)?.cancel(NOTIFICATION_ID)
        } catch (e: Exception) {
            Log.w(TAG, "Failed to remove the running notification", e)
        }
    }
}
