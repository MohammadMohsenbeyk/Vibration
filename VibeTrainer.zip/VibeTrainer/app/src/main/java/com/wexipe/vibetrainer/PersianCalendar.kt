package com.wexipe.vibetrainer

import java.util.Calendar
import java.util.TimeZone

/**
 * A small, self-contained Gregorian-to-Jalali (Persian/Shamsi) calendar converter. No
 * external calendar library is used - this is the well-known, widely-published conversion
 * algorithm (an arithmetic approximation valid for the modern era), reimplemented directly
 * so the app stays dependency-free.
 */
object PersianCalendar {

    private val monthNames = arrayOf(
        "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
        "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
    )

    private fun gregorianToJalali(gy: Int, gm: Int, gd: Int): Triple<Int, Int, Int> {
        val gDaysInMonth = intArrayOf(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)
        val gy2 = if (gm > 2) gy + 1 else gy
        var days = 355666 + (365 * gy) + ((gy2 + 3) / 4) - ((gy2 + 99) / 100) +
            ((gy2 + 399) / 400) + gd + gDaysInMonth[gm - 1]

        var jy = -1595 + (33 * (days / 12053))
        days %= 12053
        jy += 4 * (days / 1461)
        days %= 1461
        if (days > 365) {
            jy += (days - 1) / 365
            days = (days - 1) % 365
        }
        val jm: Int
        val jd: Int
        if (days < 186) {
            jm = 1 + days / 31
            jd = 1 + (days % 31)
        } else {
            jm = 7 + (days - 186) / 30
            jd = 1 + ((days - 186) % 30)
        }
        return Triple(jy, jm, jd)
    }

    /** "۲۷ شهریور ۱۴۰۳" - day, Persian month name, year - using the device's local time zone. */
    fun formatDate(millis: Long): String {
        val cal = Calendar.getInstance(TimeZone.getDefault())
        cal.timeInMillis = millis
        val (jy, jm, jd) = gregorianToJalali(
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH) + 1,
            cal.get(Calendar.DAY_OF_MONTH)
        )
        val monthName = monthNames[(jm - 1).coerceIn(0, 11)]
        return StatusUtils.toPersianDigits("$jd") + " $monthName " + StatusUtils.toPersianDigits("$jy")
    }
}
