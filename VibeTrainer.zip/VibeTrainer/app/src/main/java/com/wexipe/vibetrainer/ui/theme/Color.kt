package com.wexipe.vibetrainer.ui.theme

import androidx.compose.ui.graphics.Color

/**
 * A real, named Color System - not a single accent reused everywhere. Every role below is
 * defined for BOTH the light theme (primary/default) and the polished dark theme, so
 * MaterialTheme's roles and the extra semantic colors in [VibeExtraColors] never fall back
 * to an improvised value.
 */

// ---- Light theme (default) ----
val LightBackground = Color(0xFFF7F8FA)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF0F2F5)
val LightBorder = Color(0xFFE2E5E9)

val LightPrimary = Color(0xFF00796B)         // deep teal - the app's one accent, used deliberately
val LightOnPrimary = Color(0xFFFFFFFF)
val LightPrimaryContainer = Color(0xFFB2DFDB)
val LightOnPrimaryContainer = Color(0xFF00251A)

val LightSecondary = Color(0xFF4A6360)
val LightOnSecondaryContainer = Color(0xFF0B1F1C)
val LightSecondaryContainer = Color(0xFFD3E5E1)

val LightTextPrimary = Color(0xFF1A1C1E)
val LightTextSecondary = Color(0xFF5F6368)

val LightSuccess = Color(0xFF2E7D32)
val LightSuccessContainer = Color(0xFFDCEDC8)
val LightWarning = Color(0xFFB86E00)
val LightWarningContainer = Color(0xFFFFE7C2)
val LightError = Color(0xFFC62828)
val LightErrorContainer = Color(0xFFFFDAD6)

// ---- Dark theme (kept, redesigned to match the same system) ----
val DarkBackground = Color(0xFF101214)
val DarkSurface = Color(0xFF17191C)
val DarkSurfaceVariant = Color(0xFF1F2226)
val DarkBorder = Color(0xFF2A2D31)

val DarkPrimary = Color(0xFF4DD0C4)
val DarkOnPrimary = Color(0xFF00332C)
val DarkPrimaryContainer = Color(0xFF00504A)
val DarkOnPrimaryContainer = Color(0xFFB2DFDB)

val DarkSecondary = Color(0xFFA9C5C0)
val DarkOnSecondaryContainer = Color(0xFFD3E5E1)
val DarkSecondaryContainer = Color(0xFF334441)

val DarkTextPrimary = Color(0xFFECEDEE)
val DarkTextSecondary = Color(0xFFA9AEB4)

val DarkSuccess = Color(0xFF81C784)
val DarkSuccessContainer = Color(0xFF2E4A2F)
val DarkWarning = Color(0xFFFFB74D)
val DarkWarningContainer = Color(0xFF4A3418)
val DarkError = Color(0xFFEF5350)
val DarkErrorContainer = Color(0xFF4A2323)
