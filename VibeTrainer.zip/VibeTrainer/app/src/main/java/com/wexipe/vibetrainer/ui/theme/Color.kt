package com.wexipe.vibetrainer.ui.theme

import androidx.compose.ui.graphics.Color

val AccentTeal = Color(0xFF00E5C0)
val DeepNavy = Color(0xFF1B1F3B)
val SurfaceDark = Color(0xFF12142B)
val OnSurfaceLight = Color(0xFFE9EAF5)
val Warn = Color(0xFFFFB020)
val Danger = Color(0xFFFF5C5C)
