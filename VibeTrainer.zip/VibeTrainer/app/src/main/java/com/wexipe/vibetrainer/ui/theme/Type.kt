package com.wexipe.vibetrainer.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.wexipe.vibetrainer.R

/**
 * The app ships exactly two font files (Kalameh Medium and Bold, provided by the user) -
 * no other font is used anywhere. Compose's default Material3 type scale references four
 * distinct weights (Normal, Medium, SemiBold, Bold) across its styles; both real files are
 * registered under two weight slots each so every style in [VibeTypography] below resolves
 * to one of our two actual fonts instead of silently falling back to the system font.
 */
val KalamehFontFamily = FontFamily(
    Font(R.font.kalameh_medium, FontWeight.Normal),
    Font(R.font.kalameh_medium, FontWeight.Medium),
    Font(R.font.kalameh_bold, FontWeight.SemiBold),
    Font(R.font.kalameh_bold, FontWeight.Bold)
)

/**
 * A full Material3 type scale, deliberately weighted per role rather than defaulting
 * everything to one weight:
 * - Bold: the main hero numbers/headings (next-run time, the big status) - things that
 *   must be readable at a glance.
 * - Medium: section headings, body text, labels, buttons - everything else. Medium
 *   (not Normal) is used as the "regular" weight throughout since Kalameh's Medium file
 *   IS this app's normal reading weight - there is no separate Regular/Light file.
 */
val VibeTypography = Typography(
    displayLarge = TextStyle(fontFamily = KalamehFontFamily, fontWeight = FontWeight.Bold, fontSize = 45.sp, lineHeight = 52.sp),
    displayMedium = TextStyle(fontFamily = KalamehFontFamily, fontWeight = FontWeight.Bold, fontSize = 36.sp, lineHeight = 44.sp),
    displaySmall = TextStyle(fontFamily = KalamehFontFamily, fontWeight = FontWeight.Bold, fontSize = 32.sp, lineHeight = 40.sp),

    headlineLarge = TextStyle(fontFamily = KalamehFontFamily, fontWeight = FontWeight.Bold, fontSize = 28.sp, lineHeight = 36.sp),
    headlineMedium = TextStyle(fontFamily = KalamehFontFamily, fontWeight = FontWeight.Bold, fontSize = 24.sp, lineHeight = 32.sp),
    headlineSmall = TextStyle(fontFamily = KalamehFontFamily, fontWeight = FontWeight.Bold, fontSize = 20.sp, lineHeight = 28.sp),

    titleLarge = TextStyle(fontFamily = KalamehFontFamily, fontWeight = FontWeight.Bold, fontSize = 19.sp, lineHeight = 26.sp),
    titleMedium = TextStyle(fontFamily = KalamehFontFamily, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, lineHeight = 22.sp),
    titleSmall = TextStyle(fontFamily = KalamehFontFamily, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, lineHeight = 20.sp),

    bodyLarge = TextStyle(fontFamily = KalamehFontFamily, fontWeight = FontWeight.Medium, fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontFamily = KalamehFontFamily, fontWeight = FontWeight.Medium, fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontFamily = KalamehFontFamily, fontWeight = FontWeight.Medium, fontSize = 12.sp, lineHeight = 18.sp),

    labelLarge = TextStyle(fontFamily = KalamehFontFamily, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, lineHeight = 20.sp),
    labelMedium = TextStyle(fontFamily = KalamehFontFamily, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, lineHeight = 16.sp),
    labelSmall = TextStyle(fontFamily = KalamehFontFamily, fontWeight = FontWeight.Medium, fontSize = 11.sp, lineHeight = 16.sp)
)

// Backward-compatible alias used while migrating call sites in this phase.
val Typography = VibeTypography
