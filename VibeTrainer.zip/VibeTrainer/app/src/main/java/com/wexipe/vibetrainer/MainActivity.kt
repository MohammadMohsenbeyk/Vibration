package com.wexipe.vibetrainer

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.wexipe.vibetrainer.ui.components.ChipRow
import com.wexipe.vibetrainer.ui.components.LabeledRow
import com.wexipe.vibetrainer.ui.components.PulsingDot
import com.wexipe.vibetrainer.ui.components.SectionCard
import com.wexipe.vibetrainer.ui.components.StatusChip
import com.wexipe.vibetrainer.ui.components.StatusLevel
import com.wexipe.vibetrainer.ui.theme.Dimens
import com.wexipe.vibetrainer.ui.theme.LocalVibeExtraColors
import com.wexipe.vibetrainer.ui.theme.VibeTrainerTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var settings by remember { mutableStateOf(VibeSettings()) }
            var hasLoaded by remember { mutableStateOf(false) }
            LaunchedEffect(Unit) {
                PrefsManager.flow(this@MainActivity).collect {
                    settings = it
                    hasLoaded = true
                }
            }
            VibeTrainerTheme(themeMode = settings.themeMode) {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    DashboardScreen(settings = settings, hasLoaded = hasLoaded)
                }
            }
        }
    }
}

@Composable
fun DashboardScreen(settings: VibeSettings, hasLoaded: Boolean) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()

    // A light ticker so the countdown and the next-run time stay accurate while the
    // Dashboard is on screen, without needing a full-blown timer subsystem.
    var nowTick by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(30_000)
            nowTick = System.currentTimeMillis()
        }
    }

    var statusRefresh by remember { mutableStateOf(0) }
    val lifecycleOwner = androidx.compose.ui.platform.LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) {
                // The user may have just come back from the Exact Alarm / Battery
                // Optimization system screen - refresh the compact status chips and the
                // countdown immediately instead of waiting for the next 30s tick.
                statusRefresh++
                nowTick = System.currentTimeMillis()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    val hasVibrator = remember(statusRefresh) { VibrationManager.hasVibrator(context) }
    val canExact = remember(statusRefresh, settings.enabled) { AlarmScheduler.canScheduleExact(context) }
    val ignoringBattery = remember(statusRefresh) { StatusUtils.isIgnoringBatteryOptimizations(context) }
    val testRunning by VibrationService.isRunning.collectAsState()

    Scaffold(containerColor = MaterialTheme.colorScheme.background) { padding ->
        if (!hasLoaded) {
            Column(
                Modifier.fillMaxSize().padding(padding),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
            }
            return@Scaffold
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = Dimens.spaceMd, vertical = Dimens.spaceSm)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(Dimens.spaceMd)
        ) {

            // ---- Header ----
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(stringResource(R.string.app_name), style = MaterialTheme.typography.headlineSmall)
                IconButton(onClick = {
                    context.startActivity(Intent(context, SettingsActivity::class.java))
                }) {
                    Icon(Icons.Filled.Settings, contentDescription = "تنظیمات")
                }
            }

            // ---- Hero status card ----
            SectionCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    StatusChip(
                        text = if (settings.enabled) "اجرای خودکار فعال" else "اجرای خودکار غیرفعال",
                        level = if (settings.enabled) StatusLevel.SUCCESS else StatusLevel.NEUTRAL
                    )
                    Switch(
                        checked = settings.enabled,
                        colors = SwitchDefaults.colors(checkedThumbColor = MaterialTheme.colorScheme.primary),
                        modifier = Modifier.semantics {
                            contentDescription = "فعال یا غیرفعال کردن اجرای خودکار روزانه"
                        },
                        onCheckedChange = { checked ->
                            scope.launch {
                                PrefsManager.setEnabled(context, checked)
                                if (checked) {
                                    val fresh = PrefsManager.snapshot(context)
                                    val next = AlarmScheduler.computeNextTrigger(
                                        System.currentTimeMillis(),
                                        fresh.intervalMinutes,
                                        fresh.startMinutes,
                                        fresh.endMinutes,
                                        isInitial = true
                                    )
                                    AlarmScheduler.scheduleAt(context, next)
                                    PrefsManager.setNextAlarmTime(context, next)
                                } else {
                                    // Turning the daily system off only cancels FUTURE
                                    // alarms - it deliberately does not touch
                                    // VibrationService, so a pattern already running
                                    // right now is allowed to finish untouched. See
                                    // VibrationService.finishAutomaticRun.
                                    AlarmScheduler.cancel(context)
                                    PrefsManager.setNextAlarmTime(context, 0L)
                                }
                                statusRefresh++
                            }
                        }
                    )
                }

                AnimatedVisibility(visible = testRunning) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PulsingDot(color = MaterialTheme.colorScheme.primary)
                        Text("در حال اجرای ویبره…", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
                    }
                }

                if (settings.enabled) {
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            StatusUtils.formatCountdown(nowTick, settings.nextAlarmTime),
                            style = MaterialTheme.typography.headlineMedium
                        )
                        if (settings.nextAlarmTime > 0) {
                            Text(
                                "زمان دقیق: ${StatusUtils.formatTime(settings.nextAlarmTime)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = LocalVibeExtraColors.current.textSecondary
                            )
                        }
                    }
                } else {
                    Text(
                        "برای شروع اجرای خودکار، کلید بالا را فعال کنید",
                        style = MaterialTheme.typography.bodyMedium,
                        color = LocalVibeExtraColors.current.textSecondary
                    )
                }

                HorizontalDivider(color = LocalVibeExtraColors.current.border)
                LabeledRow("آخرین اجرای موفق", StatusUtils.formatTime(settings.lastRunTime))
                LabeledRow(
                    "فاصله اجرا",
                    StatusUtils.formatIntervalLabel(settings.intervalMinutes)
                )
            }

            // ---- Primary action ----
            Button(
                onClick = {
                    VibrationService.startTest(
                        context,
                        settings.vibrationDurationMs,
                        settings.pauseDurationMs,
                        settings.repeatCount,
                        settings.amplitude
                    )
                },
                enabled = !testRunning && hasVibrator,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                shape = MaterialTheme.shapes.medium
            ) {
                Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(Modifier.size(8.dp))
                Text(if (testRunning) "در حال اجرای تست…" else if (!hasVibrator) "این دستگاه موتور ویبره ندارد" else "تست ویبره")
            }

            // ---- Compact system status ----
            SectionCard(title = "وضعیت سیستم", subtitle = "برای جزئیات و رفع مشکل، وارد تنظیمات شوید") {
                ChipRow {
                    StatusChip(
                        text = "لرزاننده",
                        level = if (hasVibrator) StatusLevel.SUCCESS else StatusLevel.ERROR
                    )
                    StatusChip(
                        text = "زمان‌بندی",
                        level = if (canExact) StatusLevel.SUCCESS else StatusLevel.WARNING
                    )
                    StatusChip(
                        text = "باتری",
                        level = if (ignoringBattery) StatusLevel.SUCCESS else StatusLevel.WARNING
                    )
                }
            }

            Spacer(Modifier.height(4.dp))
        }
    }
}
