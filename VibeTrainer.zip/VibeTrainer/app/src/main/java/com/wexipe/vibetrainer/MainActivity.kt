package com.wexipe.vibetrainer

import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.wexipe.vibetrainer.ui.theme.VibeTrainerTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            VibeTrainerTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    HomeScreen()
                }
            }
        }
    }
}

@Composable
fun HomeScreen() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()

    var settings by remember { mutableStateOf(VibeSettings()) }
    var refreshTick by remember { mutableStateOf(0) }

    LaunchedEffect(Unit) {
        PrefsManager.flow(context).collect { settings = it }
    }
    // Re-check hardware/permission status (they can change while the app is backgrounded,
    // e.g. user grants exact-alarm permission and comes back).
    LaunchedEffect(refreshTick) { /* triggers recomposition read of StatusUtils below */ }

    val hasVibrator = remember(refreshTick) { VibrationManager.hasVibrator(context) }
    val canExact = remember(refreshTick, settings.enabled) { AlarmScheduler.canScheduleExact(context) }
    val ignoringBattery =
        remember(refreshTick) { StatusUtils.isIgnoringBatteryOptimizations(context) }

    Scaffold { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "VibeTrainer",
                style = MaterialTheme.typography.titleLarge
            )
            Text(
                text = "لرزاندن خودکار روزی یک‌بار برای فعال نگه‌داشتن موتور ویبره",
                style = MaterialTheme.typography.bodyLarge
            )

            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("وضعیت سیستم روزانه", style = MaterialTheme.typography.titleMedium)
                            Text(
                                if (settings.enabled) "فعال" else "غیرفعال",
                                color = if (settings.enabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Switch(
                            checked = settings.enabled,
                            onCheckedChange = { checked ->
                                scope.launch {
                                    PrefsManager.setEnabled(context, checked)
                                    if (checked) {
                                        val fresh = PrefsManager.snapshot(context)
                                        val next = AlarmScheduler.computeNextTrigger(
                                            System.currentTimeMillis(),
                                            fresh.startMinutes,
                                            fresh.endMinutes,
                                            isInitial = true
                                        )
                                        AlarmScheduler.scheduleAt(context, next)
                                        PrefsManager.setNextAlarmTime(context, next)
                                    } else {
                                        AlarmScheduler.cancel(context)
                                        PrefsManager.setNextAlarmTime(context, 0L)
                                    }
                                    refreshTick++
                                }
                            }
                        )
                    }
                    Spacer(Modifier.height(2.dp))
                    InfoRow("زمان آخرین ویبره خودکار", StatusUtils.formatTime(settings.lastRunTime))
                    InfoRow("زمان ویبره بعدی", StatusUtils.formatTime(settings.nextAlarmTime))
                    if (settings.lastTestTime > 0L) {
                        InfoRow("آخرین تست دستی", StatusUtils.formatTime(settings.lastTestTime))
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = {
                    scope.launch {
                        VibrationManager.runPattern(
                            context,
                            settings.vibrationDurationMs,
                            settings.pauseDurationMs,
                            settings.repeatCount,
                            settings.amplitude
                        )
                        PrefsManager.setLastTestTime(context, System.currentTimeMillis())
                    }
                }) {
                    Text("تست ویبره")
                }
                OutlinedButton(onClick = {
                    context.startActivity(Intent(context, SettingsActivity::class.java))
                }) {
                    Text("تنظیمات")
                }
            }

            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("وضعیت سیستم", style = MaterialTheme.typography.titleMedium)

                    StatusLine(
                        label = "قابلیت ویبره",
                        ok = hasVibrator,
                        okText = "فعال",
                        badText = "این دستگاه موتور ویبره ندارد"
                    )

                    StatusLine(
                        label = "زمان‌بندی دقیق (Alarm)",
                        ok = canExact,
                        okText = "آماده",
                        badText = "نیاز به دسترسی Exact Alarm"
                    )
                    if (!canExact && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        OutlinedButton(onClick = { AlarmScheduler.openExactAlarmSettings(context) }) {
                            Text("باز کردن تنظیمات Exact Alarm")
                        }
                    }

                    StatusLine(
                        label = "بهینه‌سازی باتری",
                        ok = ignoringBattery,
                        okText = "برنامه از بهینه‌سازی باتری مستثناست",
                        badText = "ممکن است اجرای پس‌زمینه با تأخیر مواجه شود"
                    )
                    if (!ignoringBattery) {
                        OutlinedButton(onClick = { StatusUtils.requestIgnoreBatteryOptimizations(context) }) {
                            Text("درخواست معافیت از بهینه‌سازی باتری")
                        }
                    }

                    Text(
                        "توجه: در برخی گوشی‌های سامسونگ، صرف‌نظر از این تنظیمات، مدیریت پس‌زمینه اختصاصی سامسونگ می‌تواند اجرا را به تأخیر بیندازد. این محدودیت خارج از کنترل این برنامه است؛ در صورت بروز تأخیر، برنامه را در تنظیمات باتری گوشی روی «بدون محدودیت» قرار دهید.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )
                }
            }
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f))
        Text(value, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun StatusLine(label: String, ok: Boolean, okText: String, badText: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label)
        Text(
            if (ok) okText else badText,
            color = if (ok) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
        )
    }
}
