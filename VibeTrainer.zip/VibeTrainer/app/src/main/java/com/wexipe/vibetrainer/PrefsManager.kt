package com.wexipe.vibetrainer

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

/**
 * Every persisted value the app needs, in one place. Backed by Jetpack DataStore so it
 * survives process death / app close, matching the "enabled, startTime, endTime,
 * vibrationDuration, pauseDuration, repeatCount, amplitude, nextAlarmTime, lastRunTime"
 * requirement.
 */
private val Context.dataStore by preferencesDataStore(name = "vibe_trainer_prefs")

data class VibeSettings(
    val enabled: Boolean = false,
    // Minutes since midnight, local time.
    val startMinutes: Int = DEFAULT_START_MINUTES,
    val endMinutes: Int = DEFAULT_END_MINUTES,
    val vibrationDurationMs: Long = DEFAULT_VIBRATION_MS,
    val pauseDurationMs: Long = DEFAULT_PAUSE_MS,
    val repeatCount: Int = DEFAULT_REPEAT_COUNT,
    // 1..255, VibrationEffect amplitude scale.
    val amplitude: Int = DEFAULT_AMPLITUDE,
    // Epoch millis, 0L means "never".
    val nextAlarmTime: Long = 0L,
    val lastRunTime: Long = 0L,
    // Epoch millis, 0L means "never". Kept separate from lastRunTime because manual tests
    // must never be counted as the automatic daily run.
    val lastTestTime: Long = 0L
) {
    companion object {
        const val DEFAULT_START_MINUTES = 9 * 60      // 09:00
        const val DEFAULT_END_MINUTES = 23 * 60        // 23:00
        const val DEFAULT_VIBRATION_MS = 700L
        const val DEFAULT_PAUSE_MS = 250L
        const val DEFAULT_REPEAT_COUNT = 6
        const val DEFAULT_AMPLITUDE = 255

        // Hard safety clamps. No matter what the user types in Settings, the pattern can
        // never exceed these, so the vibration motor is never pushed into a long
        // uninterrupted run.
        const val MIN_PULSE_MS = 150L
        const val MAX_PULSE_MS = 3000L
        const val MIN_PAUSE_MS = 80L
        const val MAX_PAUSE_MS = 2000L
        const val MIN_REPEAT_COUNT = 1
        const val MAX_REPEAT_COUNT = 20
        const val MIN_AMPLITUDE = 1
        const val MAX_AMPLITUDE = 255
        const val MAX_TOTAL_PATTERN_MS = 15_000L

        fun clampStartMinutes(v: Int) = v.coerceIn(0, 23 * 60 + 59)
        fun clampEndMinutes(v: Int) = v.coerceIn(0, 23 * 60 + 59)
        fun clampVibrationMs(v: Long) = v.coerceIn(MIN_PULSE_MS, MAX_PULSE_MS)
        fun clampPauseMs(v: Long) = v.coerceIn(MIN_PAUSE_MS, MAX_PAUSE_MS)
        fun clampRepeatCount(v: Int) = v.coerceIn(MIN_REPEAT_COUNT, MAX_REPEAT_COUNT)
        fun clampAmplitude(v: Int) = v.coerceIn(MIN_AMPLITUDE, MAX_AMPLITUDE)
    }
}

object PrefsManager {

    private object Keys {
        val ENABLED = booleanPreferencesKey("enabled")
        val START_MIN = intPreferencesKey("start_minutes")
        val END_MIN = intPreferencesKey("end_minutes")
        val VIBE_MS = longPreferencesKey("vibration_duration_ms")
        val PAUSE_MS = longPreferencesKey("pause_duration_ms")
        val REPEAT = intPreferencesKey("repeat_count")
        val AMPLITUDE = intPreferencesKey("amplitude")
        val NEXT_ALARM = longPreferencesKey("next_alarm_time")
        val LAST_RUN = longPreferencesKey("last_run_time")
        val LAST_TEST = longPreferencesKey("last_test_time")
        // Marks which alarm "slot" we last scheduled/consumed, to guard against a stray
        // duplicate broadcast firing the same cycle twice.
        val LAST_SCHEDULED_FOR = stringPreferencesKey("last_scheduled_for")
    }

    fun flow(context: Context): Flow<VibeSettings> =
        context.dataStore.data.map { p ->
            VibeSettings(
                enabled = p[Keys.ENABLED] ?: false,
                startMinutes = p[Keys.START_MIN] ?: VibeSettings.DEFAULT_START_MINUTES,
                endMinutes = p[Keys.END_MIN] ?: VibeSettings.DEFAULT_END_MINUTES,
                vibrationDurationMs = p[Keys.VIBE_MS] ?: VibeSettings.DEFAULT_VIBRATION_MS,
                pauseDurationMs = p[Keys.PAUSE_MS] ?: VibeSettings.DEFAULT_PAUSE_MS,
                repeatCount = p[Keys.REPEAT] ?: VibeSettings.DEFAULT_REPEAT_COUNT,
                amplitude = p[Keys.AMPLITUDE] ?: VibeSettings.DEFAULT_AMPLITUDE,
                nextAlarmTime = p[Keys.NEXT_ALARM] ?: 0L,
                lastRunTime = p[Keys.LAST_RUN] ?: 0L,
                lastTestTime = p[Keys.LAST_TEST] ?: 0L
            )
        }

    suspend fun snapshot(context: Context): VibeSettings = flow(context).first()

    suspend fun setEnabled(context: Context, enabled: Boolean) {
        context.dataStore.edit { it[Keys.ENABLED] = enabled }
    }

    suspend fun saveSettings(
        context: Context,
        startMinutes: Int,
        endMinutes: Int,
        vibrationDurationMs: Long,
        pauseDurationMs: Long,
        repeatCount: Int,
        amplitude: Int
    ) {
        context.dataStore.edit { p ->
            p[Keys.START_MIN] = VibeSettings.clampStartMinutes(startMinutes)
            p[Keys.END_MIN] = VibeSettings.clampEndMinutes(endMinutes)
            p[Keys.VIBE_MS] = VibeSettings.clampVibrationMs(vibrationDurationMs)
            p[Keys.PAUSE_MS] = VibeSettings.clampPauseMs(pauseDurationMs)
            p[Keys.REPEAT] = VibeSettings.clampRepeatCount(repeatCount)
            p[Keys.AMPLITUDE] = VibeSettings.clampAmplitude(amplitude)
        }
    }

    suspend fun setNextAlarmTime(context: Context, timeMillis: Long) {
        context.dataStore.edit { it[Keys.NEXT_ALARM] = timeMillis }
    }

    suspend fun setLastRunTime(context: Context, timeMillis: Long) {
        context.dataStore.edit { it[Keys.LAST_RUN] = timeMillis }
    }

    suspend fun setLastTestTime(context: Context, timeMillis: Long) {
        context.dataStore.edit { it[Keys.LAST_TEST] = timeMillis }
    }

    /**
     * Identifies which local calendar day a scheduled/consumed cycle belongs to (yyyy-MM-dd).
     * Used purely as a duplicate-execution guard, so a second broadcast for the same day
     * (double alarm registration, reboot race, etc.) never vibrates twice.
     */
    suspend fun getLastScheduledFor(context: Context): String? =
        context.dataStore.data.map { it[Keys.LAST_SCHEDULED_FOR] }.first()

    suspend fun setLastScheduledFor(context: Context, dayKey: String) {
        context.dataStore.edit { it[Keys.LAST_SCHEDULED_FOR] = dayKey }
    }
}
