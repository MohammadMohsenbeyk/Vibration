package com.wexipe.vibetrainer

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

/**
 * Every persisted value the app needs, in one place. Backed by Jetpack DataStore so it
 * survives process death / app close.
 */
private val Context.dataStore by preferencesDataStore(name = "vibe_trainer_prefs")

enum class ThemeMode { LIGHT, DARK, SYSTEM }

data class VibeSettings(
    val enabled: Boolean = false,
    // Minutes since midnight, local time - the daily window vibration is allowed to run in.
    val startMinutes: Int = DEFAULT_START_MINUTES,
    val endMinutes: Int = DEFAULT_END_MINUTES,
    // How long to wait before the next run, independent of the window above (e.g. "every
    // 24 hours"). Kept as its own concept so the UI can show them as two clearly separate
    // controls, as required.
    val intervalMinutes: Int = DEFAULT_INTERVAL_MINUTES,
    val vibrationDurationMs: Long = DEFAULT_VIBRATION_MS,
    val pauseDurationMs: Long = DEFAULT_PAUSE_MS,
    val repeatCount: Int = DEFAULT_REPEAT_COUNT,
    // 1..255, VibrationEffect amplitude scale.
    val amplitude: Int = DEFAULT_AMPLITUDE,
    val themeMode: ThemeMode = ThemeMode.LIGHT,
    // Epoch millis, 0L means "never".
    val nextAlarmTime: Long = 0L,
    val lastRunTime: Long = 0L,
    // Epoch millis, 0L means "never". Kept separate from lastRunTime because manual tests
    // must never be counted as the automatic daily run.
    val lastTestTime: Long = 0L
) {
    companion object {
        const val DEFAULT_START_MINUTES = 9 * 60      // 09:00
        const val DEFAULT_END_MINUTES = 23 * 60        // 23:00
        const val DEFAULT_VIBRATION_MS = 700L
        const val DEFAULT_PAUSE_MS = 250L
        const val DEFAULT_REPEAT_COUNT = 6
        const val DEFAULT_AMPLITUDE = 255
        const val DEFAULT_INTERVAL_MINUTES = 24 * 60 // every 24h

        // Common presets shown in Settings, in minutes.
        const val INTERVAL_PRESET_10H = 10 * 60
        const val INTERVAL_PRESET_12H = 12 * 60
        const val INTERVAL_PRESET_20H = 20 * 60
        const val INTERVAL_PRESET_24H = 24 * 60

        // Hard safety clamps. No matter what the user types in Settings, the pattern can
        // never exceed these, so the vibration motor is never pushed into a long
        // uninterrupted run.
        const val MIN_PULSE_MS = 150L
        const val MAX_PULSE_MS = 3000L
        const val MIN_PAUSE_MS = 80L
        const val MAX_PAUSE_MS = 2000L
        const val MIN_REPEAT_COUNT = 1
        const val MAX_REPEAT_COUNT = 20
        const val MIN_AMPLITUDE = 1
        const val MAX_AMPLITUDE = 255
        const val MAX_TOTAL_PATTERN_MS = 15_000L

        // 1h..72h. The lower bound also underpins the duplicate-run guard in
        // AlarmReceiver (a legitimate second run can never be scheduled less than an
        // hour after the previous one), so it must never be lowered without revisiting
        // that guard.
        const val MIN_INTERVAL_MINUTES = 60
        const val MAX_INTERVAL_MINUTES = 72 * 60

        fun clampStartMinutes(v: Int) = v.coerceIn(0, 23 * 60 + 59)
        fun clampEndMinutes(v: Int) = v.coerceIn(0, 23 * 60 + 59)
        fun clampIntervalMinutes(v: Int) = v.coerceIn(MIN_INTERVAL_MINUTES, MAX_INTERVAL_MINUTES)
        fun clampVibrationMs(v: Long) = v.coerceIn(MIN_PULSE_MS, MAX_PULSE_MS)
        fun clampPauseMs(v: Long) = v.coerceIn(MIN_PAUSE_MS, MAX_PAUSE_MS)
        fun clampRepeatCount(v: Int) = v.coerceIn(MIN_REPEAT_COUNT, MAX_REPEAT_COUNT)
        fun clampAmplitude(v: Int) = v.coerceIn(MIN_AMPLITUDE, MAX_AMPLITUDE)
    }
}

object PrefsManager {

    // A legitimate automatic run can never be scheduled less than MIN_INTERVAL_MINUTES
    // apart, so any trigger arriving this soon after the last recorded run is treated as
    // a duplicate broadcast, not a real second cycle.
    const val DUPLICATE_GUARD_WINDOW_MS = 5 * 60 * 1000L

    private object Keys {
        val ENABLED = booleanPreferencesKey("enabled")
        val START_MIN = intPreferencesKey("start_minutes")
        val END_MIN = intPreferencesKey("end_minutes")
        val INTERVAL_MIN = intPreferencesKey("interval_minutes")
        val VIBE_MS = longPreferencesKey("vibration_duration_ms")
        val PAUSE_MS = longPreferencesKey("pause_duration_ms")
        val REPEAT = intPreferencesKey("repeat_count")
        val AMPLITUDE = intPreferencesKey("amplitude")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val NEXT_ALARM = longPreferencesKey("next_alarm_time")
        val LAST_RUN = longPreferencesKey("last_run_time")
        val LAST_TEST = longPreferencesKey("last_test_time")
    }

    fun flow(context: Context): Flow<VibeSettings> =
        context.dataStore.data.map { p ->
            VibeSettings(
                enabled = p[Keys.ENABLED] ?: false,
                startMinutes = p[Keys.START_MIN] ?: VibeSettings.DEFAULT_START_MINUTES,
                endMinutes = p[Keys.END_MIN] ?: VibeSettings.DEFAULT_END_MINUTES,
                intervalMinutes = p[Keys.INTERVAL_MIN] ?: VibeSettings.DEFAULT_INTERVAL_MINUTES,
                vibrationDurationMs = p[Keys.VIBE_MS] ?: VibeSettings.DEFAULT_VIBRATION_MS,
                pauseDurationMs = p[Keys.PAUSE_MS] ?: VibeSettings.DEFAULT_PAUSE_MS,
                repeatCount = p[Keys.REPEAT] ?: VibeSettings.DEFAULT_REPEAT_COUNT,
                amplitude = p[Keys.AMPLITUDE] ?: VibeSettings.DEFAULT_AMPLITUDE,
                themeMode = runCatching { ThemeMode.valueOf(p[Keys.THEME_MODE] ?: "LIGHT") }
                    .getOrDefault(ThemeMode.LIGHT),
                nextAlarmTime = p[Keys.NEXT_ALARM] ?: 0L,
                lastRunTime = p[Keys.LAST_RUN] ?: 0L,
                lastTestTime = p[Keys.LAST_TEST] ?: 0L
            )
        }

    suspend fun snapshot(context: Context): VibeSettings = flow(context).first()

    suspend fun setEnabled(context: Context, enabled: Boolean) {
        context.dataStore.edit { it[Keys.ENABLED] = enabled }
    }

    suspend fun saveScheduleSettings(context: Context, startMinutes: Int, endMinutes: Int) {
        context.dataStore.edit { p ->
            p[Keys.START_MIN] = VibeSettings.clampStartMinutes(startMinutes)
            p[Keys.END_MIN] = VibeSettings.clampEndMinutes(endMinutes)
        }
    }

    suspend fun saveIntervalMinutes(context: Context, intervalMinutes: Int) {
        context.dataStore.edit { p ->
            p[Keys.INTERVAL_MIN] = VibeSettings.clampIntervalMinutes(intervalMinutes)
        }
    }

    suspend fun savePatternSettings(
        context: Context,
        vibrationDurationMs: Long,
        pauseDurationMs: Long,
        repeatCount: Int,
        amplitude: Int
    ) {
        context.dataStore.edit { p ->
            p[Keys.VIBE_MS] = VibeSettings.clampVibrationMs(vibrationDurationMs)
            p[Keys.PAUSE_MS] = VibeSettings.clampPauseMs(pauseDurationMs)
            p[Keys.REPEAT] = VibeSettings.clampRepeatCount(repeatCount)
            p[Keys.AMPLITUDE] = VibeSettings.clampAmplitude(amplitude)
        }
    }

    suspend fun setThemeMode(context: Context, mode: ThemeMode) {
        context.dataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }

    suspend fun setNextAlarmTime(context: Context, timeMillis: Long) {
        context.dataStore.edit { it[Keys.NEXT_ALARM] = timeMillis }
    }

    suspend fun setLastRunTime(context: Context, timeMillis: Long) {
        context.dataStore.edit { it[Keys.LAST_RUN] = timeMillis }
    }

    suspend fun setLastTestTime(context: Context, timeMillis: Long) {
        context.dataStore.edit { it[Keys.LAST_TEST] = timeMillis }
    }
}
