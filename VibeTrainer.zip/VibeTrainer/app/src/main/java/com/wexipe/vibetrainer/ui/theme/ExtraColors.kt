package com.wexipe.vibetrainer.ui.theme

import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/**
 * Material3's ColorScheme only has native roles for primary/secondary/tertiary/error - it
 * has no built-in "success" or "warning" role. Rather than misusing tertiary/error for
 * meanings they don't represent, this app defines its own small, explicit extension,
 * provided alongside MaterialTheme so any Composable can read `LocalVibeExtraColors.current`
 * the same way it reads `MaterialTheme.colorScheme`.
 */
data class VibeExtraColors(
    val success: Color,
    val onSuccess: Color,
    val successContainer: Color,
    val onSuccessContainer: Color,
    val warning: Color,
    val onWarning: Color,
    val warningContainer: Color,
    val onWarningContainer: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val border: Color
)

val LightExtraColors = VibeExtraColors(
    success = LightSuccess,
    onSuccess = Color.White,
    successContainer = LightSuccessContainer,
    onSuccessContainer = Color(0xFF12260F),
    warning = LightWarning,
    onWarning = Color.White,
    warningContainer = LightWarningContainer,
    onWarningContainer = Color(0xFF3A2600),
    textPrimary = LightTextPrimary,
    textSecondary = LightTextSecondary,
    border = LightBorder
)

val DarkExtraColors = VibeExtraColors(
    success = DarkSuccess,
    onSuccess = Color(0xFF0F2711),
    successContainer = DarkSuccessContainer,
    onSuccessContainer = Color(0xFFC8E6C9),
    warning = DarkWarning,
    onWarning = Color(0xFF3A2600),
    warningContainer = DarkWarningContainer,
    onWarningContainer = Color(0xFFFFE0B2),
    textPrimary = DarkTextPrimary,
    textSecondary = DarkTextSecondary,
    border = DarkBorder
)

val LocalVibeExtraColors = staticCompositionLocalOf { LightExtraColors }
