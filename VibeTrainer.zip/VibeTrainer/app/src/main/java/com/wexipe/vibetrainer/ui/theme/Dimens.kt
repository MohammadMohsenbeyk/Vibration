package com.wexipe.vibetrainer.ui.theme

import androidx.compose.ui.unit.dp

/**
 * The single source of truth for spacing in the app. Every Composable should reach for
 * these instead of a locally-invented dp value, so spacing stays consistent everywhere.
 */
object Dimens {
    val spaceXs = 4.dp
    val spaceSm = 8.dp
    val spaceMd = 16.dp
    val spaceLg = 24.dp
    val spaceXl = 32.dp

    // Minimum comfortable touch target (Material/HIG accessibility guidance).
    val minTouchTarget = 48.dp

    val iconSm = 18.dp
    val iconMd = 24.dp
    val iconLg = 40.dp
}
