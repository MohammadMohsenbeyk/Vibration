package com.wexipe.vibetrainer.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val VibeTrainerColorScheme = darkColorScheme(
    primary = AccentTeal,
    background = SurfaceDark,
    surface = DeepNavy,
    onPrimary = SurfaceDark,
    onBackground = OnSurfaceLight,
    onSurface = OnSurfaceLight,
    error = Danger
)

@Composable
fun VibeTrainerTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = VibeTrainerColorScheme,
        typography = Typography,
        content = content
    )
}
