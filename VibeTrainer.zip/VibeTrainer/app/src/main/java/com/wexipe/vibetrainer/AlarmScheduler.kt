package com.wexipe.vibetrainer

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.util.Log
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.random.Random

/**
 * Owns every decision about *when* the next run happens and how it's registered with
 * AlarmManager. MainActivity/SettingsActivity only ever call into this object - none of
 * this logic lives in the UI layer.
 */
object AlarmScheduler {

    private const val TAG = "VibeTrainer.Scheduler"
    private const val REQUEST_CODE = 4200
    const val ACTION_TRIGGER = "com.wexipe.vibetrainer.action.TRIGGER"
    private const val ONE_DAY_MS = 24L * 60L * 60L * 1000L

    private val dayKeyFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    fun dayKeyFor(timeMillis: Long): String = dayKeyFormat.format(timeMillis)

    private fun pendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = ACTION_TRIGGER
        }
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        return PendingIntent.getBroadcast(context, REQUEST_CODE, intent, flags)
    }

    fun canScheduleExact(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.canScheduleExactAlarms()
        } else {
            // Below API 31 exact alarms are available without a special user grant.
            true
        }
    }

    /**
     * Opens the system screen where the user can grant the exact-alarm permission.
     * Only relevant on API 31+; no-op below that.
     */
    fun openExactAlarmSettings(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                data = Uri.parse("package:${context.packageName}")
            }
            context.startActivity(intent)
        }
    }

    /**
     * Computes the next trigger time inside [startMinutes, endMinutes] of a local day.
     *
     * - When [isInitial] is true (system just turned on, or we're recovering after boot /
     *   a clock change and don't know the state of "today"), the target day is today if
     *   the window hasn't fully elapsed yet, otherwise tomorrow.
     * - When [isInitial] is false (we just finished a run), the target day is always the
     *   day after [now], which keeps consecutive runs roughly 24h apart while still
     *   letting the exact hour vary.
     */
    fun computeNextTrigger(
        now: Long,
        startMinutes: Int,
        endMinutes: Int,
        isInitial: Boolean
    ): Long {
        val safeStart = minOf(startMinutes, endMinutes)
        val safeEnd = maxOf(startMinutes, endMinutes)

        val cal = Calendar.getInstance().apply {
            timeInMillis = now
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val todayStart = cal.timeInMillis

        val baseDayStart = if (isInitial) {
            val todayWindowEnd = todayStart + safeEnd * 60_000L
            if (now < todayWindowEnd) todayStart else todayStart + ONE_DAY_MS
        } else {
            todayStart + ONE_DAY_MS
        }

        val windowStart = baseDayStart + safeStart * 60_000L
        val windowEnd = baseDayStart + safeEnd * 60_000L

        var trigger = if (windowEnd > windowStart) {
            Random.nextLong(windowStart, windowEnd + 1)
        } else {
            windowStart
        }

        // Safety net: never schedule in the past (e.g. isInitial with a window that just
        // barely ended between the check above and now, or a manual clock rollback).
        if (trigger <= now) {
            trigger = now + 60_000L
        }
        return trigger
    }

    /** Registers [triggerAtMillis] with AlarmManager, using exact timing when available. */
    fun scheduleAt(context: Context, triggerAtMillis: Long) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pendingIntent(context)
        am.cancel(pi) // Always clear any previously registered alarm first.

        try {
            if (canScheduleExact(context)) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi)
                Log.d(TAG, "Scheduled EXACT alarm for $triggerAtMillis")
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi)
                Log.d(TAG, "Exact alarms unavailable, scheduled inexact alarm for $triggerAtMillis")
            }
        } catch (e: SecurityException) {
            // Exact alarm permission revoked between the check and the call - fall back.
            Log.w(TAG, "Exact alarm denied, falling back to inexact", e)
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi)
        }
    }

    fun cancel(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pendingIntent(context))
        Log.d(TAG, "Alarm cancelled")
    }
}
