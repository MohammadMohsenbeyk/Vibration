package com.wexipe.vibetrainer

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.util.Log
import java.util.Calendar
import kotlin.random.Random

/**
 * Owns every decision about *when* the next run happens and how it's registered with
 * AlarmManager. MainActivity/SettingsActivity only ever call into this object - none of
 * this logic lives in the UI layer.
 */
object AlarmScheduler {

    private const val TAG = "VibeTrainer.Scheduler"
    private const val REQUEST_CODE = 4200
    const val ACTION_TRIGGER = "com.wexipe.vibetrainer.action.TRIGGER"
    private const val ONE_DAY_MS = 24L * 60L * 60L * 1000L

    private fun pendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = ACTION_TRIGGER
        }
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        return PendingIntent.getBroadcast(context, REQUEST_CODE, intent, flags)
    }

    fun canScheduleExact(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.canScheduleExactAlarms()
        } else {
            // Below API 31 exact alarms are available without a special user grant.
            true
        }
    }

    /**
     * Opens the system screen where the user can grant the exact-alarm permission.
     * Only relevant on API 31+; no-op below that.
     */
    fun openExactAlarmSettings(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                data = Uri.parse("package:${context.packageName}")
            }
            context.startActivity(intent)
        }
    }

    /**
     * Computes the next trigger time.
     *
     * - When [isInitial] is true (system just turned on, or we're recovering after boot /
     *   a clock change and have no reliable "last run" reference), the target is a random
     *   moment inside [startMinutes, endMinutes] - today if that window hasn't fully
     *   elapsed yet, otherwise tomorrow. [intervalMinutes] is not used in this case: there
     *   is nothing to measure the interval from yet.
     * - When [isInitial] is false (a run just finished), the target is exactly
     *   `now + intervalMinutes` - so the interval the user picked (e.g. "every 12 hours")
     *   is honored precisely - UNLESS that falls outside the allowed daily window, in
     *   which case it's pulled into the nearest valid window:
     *     - before the window opens that day -> pushed to that day's window start
     *     - after the window closes that day  -> pushed to a random moment in the NEXT
     *       day's window (a small amount of randomness here, same as the initial case,
     *       since at that point we're effectively re-anchoring like a fresh start)
     *
     * This keeps "فاصله اجرا" (interval) and "بازه مجاز" (allowed window) genuinely
     * independent concepts, exactly as required, while guaranteeing every trigger still
     * respects the allowed time-of-day window.
     */
    fun computeNextTrigger(
        now: Long,
        intervalMinutes: Int,
        startMinutes: Int,
        endMinutes: Int,
        isInitial: Boolean
    ): Long {
        val safeStart = minOf(startMinutes, endMinutes)
        val safeEnd = maxOf(startMinutes, endMinutes)

        fun dayStartOf(timeMillis: Long): Long = Calendar.getInstance().apply {
            timeInMillis = timeMillis
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis

        fun randomWithinWindow(dayStart: Long): Long {
            val windowStart = dayStart + safeStart * 60_000L
            val windowEnd = dayStart + safeEnd * 60_000L
            return if (windowEnd > windowStart) Random.nextLong(windowStart, windowEnd + 1) else windowStart
        }

        var trigger = if (isInitial) {
            val todayStart = dayStartOf(now)
            val todayWindowEnd = todayStart + safeEnd * 60_000L
            randomWithinWindow(if (now < todayWindowEnd) todayStart else todayStart + ONE_DAY_MS)
        } else {
            val anchor = now + intervalMinutes * 60_000L
            val anchorDayStart = dayStartOf(anchor)
            val windowStart = anchorDayStart + safeStart * 60_000L
            val windowEnd = anchorDayStart + safeEnd * 60_000L
            when {
                anchor < windowStart -> windowStart
                anchor > windowEnd -> randomWithinWindow(anchorDayStart + ONE_DAY_MS)
                else -> anchor
            }
        }

        // Safety net: never schedule in the past (e.g. a window that just barely ended,
        // or a manual clock rollback).
        if (trigger <= now) {
            trigger = now + 60_000L
        }
        return trigger
    }

    /** Registers [triggerAtMillis] with AlarmManager, using exact timing when available. */
    fun scheduleAt(context: Context, triggerAtMillis: Long) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pendingIntent(context)
        am.cancel(pi) // Always clear any previously registered alarm first.

        try {
            if (canScheduleExact(context)) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi)
                Log.d(TAG, "Scheduled EXACT alarm for $triggerAtMillis")
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi)
                Log.d(TAG, "Exact alarms unavailable, scheduled inexact alarm for $triggerAtMillis")
            }
        } catch (e: SecurityException) {
            // Exact alarm permission revoked between the check and the call - fall back.
            Log.w(TAG, "Exact alarm denied, falling back to inexact", e)
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi)
        }
    }

    fun cancel(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pendingIntent(context))
        Log.d(TAG, "Alarm cancelled")
    }
}
