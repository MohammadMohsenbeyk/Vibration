package com.wexipe.vibetrainer

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings

object StatusUtils {

    fun isIgnoringBatteryOptimizations(context: Context): Boolean {
        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(context.packageName)
    }

    /**
     * Sends the user straight to the "allow this app to ignore battery optimizations"
     * system dialog for our own package. We only ever surface this as an optional button
     * in Settings/System status - the app never forces it and works without it (just with
     * a small risk of a delayed trigger under aggressive Doze on some OEMs).
     */
    fun requestIgnoreBatteryOptimizations(context: Context) {
        val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
            data = Uri.parse("package:${context.packageName}")
        }
        context.startActivity(intent)
    }

    /** Fallback for OEMs (or API levels) where the direct-request dialog isn't available. */
    fun openBatteryOptimizationSettingsList(context: Context) {
        val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
        context.startActivity(intent)
    }

    fun openAppDetailsSettings(context: Context) {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.parse("package:${context.packageName}")
        }
        context.startActivity(intent)
    }

    fun formatTime(millis: Long): String {
        if (millis <= 0L) return "—"
        val fmt = java.text.SimpleDateFormat("yyyy/MM/dd HH:mm", java.util.Locale.US)
        return fmt.format(millis)
    }
}
