package com.wexipe.vibetrainer

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings

object StatusUtils {

    fun isIgnoringBatteryOptimizations(context: Context): Boolean {
        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(context.packageName)
    }

    /**
     * Sends the user straight to the "allow this app to ignore battery optimizations"
     * system dialog for our own package. We only ever surface this as an optional button
     * in Settings/System status - the app never forces it and works without it (just with
     * a small risk of a delayed trigger under aggressive Doze on some OEMs).
     */
    fun requestIgnoreBatteryOptimizations(context: Context) {
        val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
            data = Uri.parse("package:${context.packageName}")
        }
        context.startActivity(intent)
    }

    /** Fallback for OEMs (or API levels) where the direct-request dialog isn't available. */
    fun openBatteryOptimizationSettingsList(context: Context) {
        val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
        context.startActivity(intent)
    }

    fun openAppDetailsSettings(context: Context) {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.parse("package:${context.packageName}")
        }
        context.startActivity(intent)
    }

    fun formatTime(millis: Long, emptyText: String = "هنوز ثبت نشده"): String {
        if (millis <= 0L) return emptyText
        val clock = java.text.SimpleDateFormat("HH:mm", java.util.Locale.US)
        val date = PersianCalendar.formatDate(millis)
        return "$date - ${toPersianDigits(clock.format(millis))}"
    }

    /** Converts ASCII digits 0-9 in [text] to Persian digits, for a fully Persian-feeling UI. */
    fun toPersianDigits(text: String): String {
        val persian = charArrayOf('۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹')
        val builder = StringBuilder(text.length)
        for (ch in text) {
            builder.append(if (ch in '0'..'9') persian[ch - '0'] else ch)
        }
        return builder.toString()
    }

    /**
     * A short, human "X ساعت و Y دقیقه دیگر" countdown string. Falls back to a calm
     * message when the target is unset or already in the past (e.g. between a run
     * finishing and the next alarm being armed).
     */
    fun formatCountdown(nowMillis: Long, targetMillis: Long): String {
        if (targetMillis <= 0L) return "هنوز زمان‌بندی نشده"
        val diff = targetMillis - nowMillis
        if (diff <= 0L) return "به‌زودی"
        val totalMinutes = diff / 60_000L
        val hours = totalMinutes / 60
        val minutes = totalMinutes % 60
        val text = when {
            hours > 0 && minutes > 0 -> "$hours ساعت و $minutes دقیقه دیگر"
            hours > 0 -> "$hours ساعت دیگر"
            minutes > 0 -> "$minutes دقیقه دیگر"
            else -> "کمتر از یک دقیقه دیگر"
        }
        return toPersianDigits(text)
    }

    /** "هر ۱۰ ساعت" / "هر ۱ ساعت و ۳۰ دقیقه" - a readable label for an interval in minutes. */
    fun formatIntervalLabel(minutes: Int): String {
        val hours = minutes / 60
        val mins = minutes % 60
        val text = when {
            mins == 0 -> "هر $hours ساعت"
            hours == 0 -> "هر $mins دقیقه"
            else -> "هر $hours ساعت و $mins دقیقه"
        }
        return toPersianDigits(text)
    }

    /** "۰۹:۰۰" style time-of-day label from minutes-since-midnight. */
    fun formatMinutesOfDay(minutes: Int): String {
        val h = minutes / 60
        val m = minutes % 60
        return toPersianDigits("%02d:%02d".format(h, m))
    }

    /** "۲٫۵ ثانیه" style label for a pattern duration given in milliseconds (Persian decimal separator). */
    fun formatPatternDuration(totalMs: Long): String {
        val seconds = totalMs / 1000.0
        val text = if (totalMs < 1000) "$totalMs میلی‌ثانیه" else "%.1f ثانیه".format(seconds)
        return toPersianDigits(text).replace('.', '٫')
    }
}
