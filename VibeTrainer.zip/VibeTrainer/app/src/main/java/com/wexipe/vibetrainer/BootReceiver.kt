package com.wexipe.vibetrainer

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Restores the daily cycle after: device reboot, this app being updated/replaced, or the
 * system clock / time zone changing. Reads enabled state from DataStore and only ever
 * (re)registers an alarm if the system was actually turned on - never invents a new one
 * for a disabled system.
 */
class BootReceiver : BroadcastReceiver() {

    companion object {
        private const val TAG = "VibeTrainer.BootRx"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        Log.d(TAG, "Received action=$action")

        val pendingResult = goAsync()
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
        scope.launch {
            try {
                val settings = PrefsManager.snapshot(context)
                if (!settings.enabled) {
                    Log.d(TAG, "System is disabled, not registering any alarm")
                    return@launch
                }

                // We don't know whether "today's" slot for the old alarm was already
                // consumed before the reboot/clock change, so we recompute from scratch
                // with isInitial=true: today if the window is still ahead, else tomorrow.
                val now = System.currentTimeMillis()
                val next = AlarmScheduler.computeNextTrigger(
                    now,
                    settings.startMinutes,
                    settings.endMinutes,
                    isInitial = true
                )
                AlarmScheduler.scheduleAt(context, next)
                PrefsManager.setNextAlarmTime(context, next)
                Log.d(TAG, "Schedule restored, next trigger at $next")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to restore schedule on $action", e)
            } finally {
                pendingResult.finish()
            }
        }
    }
}
