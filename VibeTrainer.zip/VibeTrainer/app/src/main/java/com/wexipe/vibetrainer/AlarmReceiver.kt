package com.wexipe.vibetrainer

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Fired by AlarmManager when it's time to run the daily pattern.
 *
 * Flow (matches the required cycle exactly):
 * enabled? -> already ran this cycle? -> vibrate -> save lastRunTime -> compute next
 * trigger -> save nextAlarmTime -> register next alarm.
 *
 * Never lets an exception escape: on failure it logs and still tries to schedule the next
 * cycle, so one bad run can't silently kill the whole daily schedule.
 */
class AlarmReceiver : BroadcastReceiver() {

    companion object {
        private const val TAG = "VibeTrainer.AlarmRx"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val pendingResult = goAsync()
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
        scope.launch {
            try {
                handleTrigger(context)
            } catch (e: Exception) {
                Log.e(TAG, "Unhandled error while processing alarm trigger", e)
                // Best-effort: make sure the chain doesn't die even if something above
                // threw before it could reschedule.
                safeScheduleNext(context, isInitial = false)
            } finally {
                pendingResult.finish()
            }
        }
    }

    private suspend fun handleTrigger(context: Context) {
        val settings = PrefsManager.snapshot(context)

        if (!settings.enabled) {
            Log.d(TAG, "Trigger received but system is disabled, ignoring and not rescheduling")
            return
        }

        val now = System.currentTimeMillis()
        val todayKey = AlarmScheduler.dayKeyFor(now)
        val lastScheduledFor = PrefsManager.getLastScheduledFor(context)

        if (lastScheduledFor == todayKey) {
            // This cycle's slot was already consumed (duplicate alarm registration, a
            // stray reboot re-trigger, etc.). Do not vibrate again; just make sure a
            // future alarm exists.
            Log.w(TAG, "Duplicate trigger for cycle $todayKey ignored")
            if (settings.nextAlarmTime <= now) {
                safeScheduleNext(context, isInitial = false)
            }
            return
        }

        val ranOk = VibrationManager.runPattern(
            context,
            settings.vibrationDurationMs,
            settings.pauseDurationMs,
            settings.repeatCount,
            settings.amplitude
        )
        Log.d(TAG, "Automatic pattern run finished (success=$ranOk) for cycle $todayKey")

        PrefsManager.setLastRunTime(context, now)
        PrefsManager.setLastScheduledFor(context, todayKey)

        safeScheduleNext(context, isInitial = false)
    }

    private suspend fun safeScheduleNext(context: Context, isInitial: Boolean) {
        try {
            val settings = PrefsManager.snapshot(context)
            if (!settings.enabled) return
            val now = System.currentTimeMillis()
            val next = AlarmScheduler.computeNextTrigger(
                now,
                settings.startMinutes,
                settings.endMinutes,
                isInitial
            )
            AlarmScheduler.scheduleAt(context, next)
            PrefsManager.setNextAlarmTime(context, next)
            Log.d(TAG, "Next alarm scheduled for $next")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to schedule next cycle", e)
        }
    }
}
