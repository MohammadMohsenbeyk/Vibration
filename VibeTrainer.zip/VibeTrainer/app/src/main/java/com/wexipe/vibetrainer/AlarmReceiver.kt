package com.wexipe.vibetrainer

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Fired by AlarmManager when it's time to run the daily pattern.
 *
 * This receiver only decides WHETHER to run (enabled check, recent-run duplicate guard)
 * and then hands the actual work off to [VibrationService]. The vibrate -> notification ->
 * full pattern -> remove notification -> record last run -> compute next -> schedule next
 * alarm sequence now happens entirely inside that service, which stays alive independent
 * of this receiver's own short-lived process - see VibrationService for why.
 *
 * Never lets an exception escape: on failure it logs and still tries to schedule the next
 * cycle as a fallback, so one bad trigger can't silently kill the whole daily schedule.
 */
class AlarmReceiver : BroadcastReceiver() {

    companion object {
        private const val TAG = "VibeTrainer.AlarmRx"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val pendingResult = goAsync()
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
        scope.launch {
            try {
                handleTrigger(context)
            } catch (e: Exception) {
                Log.e(TAG, "Unhandled error while processing alarm trigger", e)
                // Best-effort: make sure the chain doesn't die even if something above
                // threw before VibrationService could take over scheduling.
                safeScheduleNext(context, isInitial = false)
            } finally {
                pendingResult.finish()
            }
        }
    }

    private suspend fun handleTrigger(context: Context) {
        val settings = PrefsManager.snapshot(context)

        if (!settings.enabled) {
            Log.d(TAG, "Trigger received but system is disabled, ignoring and not rescheduling")
            return
        }

        val now = System.currentTimeMillis()

        // A real automatic run can never legitimately be scheduled less than
        // VibeSettings.MIN_INTERVAL_MINUTES (1h) after the previous one, so anything
        // arriving within a much smaller guard window of the last recorded run is a
        // duplicate broadcast (double alarm registration, a stray reboot re-trigger,
        // etc.), not a genuine second cycle - vibrating again would be wrong.
        val sinceLastRun = now - settings.lastRunTime
        if (settings.lastRunTime > 0 && sinceLastRun in 0..PrefsManager.DUPLICATE_GUARD_WINDOW_MS) {
            Log.w(TAG, "Duplicate trigger ignored (only ${sinceLastRun}ms since the last run)")
            if (settings.nextAlarmTime <= now) {
                safeScheduleNext(context, isInitial = false)
            }
            return
        }

        // Hand off to VibrationService: it runs the full pattern independent of this
        // receiver's process, then itself records lastRunTime and schedules the next
        // cycle once the pattern has truly finished. VibrationService also guards
        // against a second, near-simultaneous trigger overlapping this one.
        VibrationService.startAutomatic(
            context,
            settings.vibrationDurationMs,
            settings.pauseDurationMs,
            settings.repeatCount,
            settings.amplitude
        )
        Log.d(TAG, "Handed off automatic run to VibrationService")
    }

    private suspend fun safeScheduleNext(context: Context, isInitial: Boolean) {
        try {
            val settings = PrefsManager.snapshot(context)
            if (!settings.enabled) return
            val now = System.currentTimeMillis()
            val next = AlarmScheduler.computeNextTrigger(
                now,
                settings.intervalMinutes,
                settings.startMinutes,
                settings.endMinutes,
                isInitial
            )
            AlarmScheduler.scheduleAt(context, next)
            PrefsManager.setNextAlarmTime(context, next)
            Log.d(TAG, "Next alarm scheduled for $next")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to schedule next cycle", e)
        }
    }
}
