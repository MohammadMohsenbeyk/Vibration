package com.wexipe.vibetrainer.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.wexipe.vibetrainer.ui.theme.Dimens
import com.wexipe.vibetrainer.ui.theme.LocalVibeExtraColors

/** The four meanings every status in the app can have - always paired with an icon and a
 * color, never color alone (accessibility: information must not depend on color only). */
enum class StatusLevel { SUCCESS, WARNING, ERROR, NEUTRAL }

/**
 * A small pill showing one status: icon + short label, colored by [level]. Used for both
 * the compact "system status" row on the Dashboard and the detailed rows in Settings, so
 * the same visual language is used everywhere a status is shown.
 */
@Composable
fun StatusChip(text: String, level: StatusLevel, modifier: Modifier = Modifier) {
    val extra = LocalVibeExtraColors.current
    val (container, content, icon) = when (level) {
        StatusLevel.SUCCESS -> Triple(extra.successContainer, extra.onSuccessContainer, Icons.Filled.CheckCircle)
        StatusLevel.WARNING -> Triple(extra.warningContainer, extra.onWarningContainer, Icons.Filled.Warning)
        StatusLevel.ERROR -> Triple(MaterialTheme.colorScheme.errorContainer, MaterialTheme.colorScheme.onErrorContainer, Icons.Filled.Error)
        StatusLevel.NEUTRAL -> Triple(MaterialTheme.colorScheme.surfaceVariant, extra.textSecondary, null)
    }
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(container)
            .padding(horizontal = Dimens.spaceSm, vertical = 6.dp)
            .semantics { contentDescription = text },
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, tint = content, modifier = Modifier.size(Dimens.iconSm))
        }
        Text(text, style = MaterialTheme.typography.labelMedium, color = content)
    }
}

/**
 * The one card container style used throughout the app - consistent corner radius,
 * padding and elevation everywhere instead of every screen inventing its own.
 */
@Composable
fun SectionCard(
    modifier: Modifier = Modifier,
    title: String? = null,
    subtitle: String? = null,
    content: @Composable () -> Unit
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            Modifier.padding(Dimens.spaceMd),
            verticalArrangement = Arrangement.spacedBy(Dimens.spaceSm)
        ) {
            if (title != null) {
                Text(title, style = MaterialTheme.typography.titleMedium)
            }
            if (subtitle != null) {
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = LocalVibeExtraColors.current.textSecondary
                )
            }
            content()
        }
    }
}

/** A plain row of label + value, RTL-safe (SpaceBetween works correctly under forced RTL). */
@Composable
fun LabeledRow(label: String, value: String, valueColor: Color = Color.Unspecified) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = LocalVibeExtraColors.current.textSecondary)
        Text(value, style = MaterialTheme.typography.titleSmall, color = if (valueColor == Color.Unspecified) MaterialTheme.colorScheme.onSurface else valueColor)
    }
}

/** A small, subtle pulsing dot used to indicate "something is actively running right now". */
@Composable
fun PulsingDot(color: Color, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "pulse")
    val alpha by transition.animateFloat(
        initialValue = 0.35f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(700, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )
    androidx.compose.foundation.layout.Box(
        modifier
            .size(10.dp)
            .clip(CircleShape)
            .background(color.copy(alpha = alpha))
    )
}

/** A horizontally spaced row helper for chip groups. Scrollable (not wrapped) on purpose:
 * a Row of chips never overflow-clips on a narrow/small phone screen, it just becomes
 * swipeable, using only stable Foundation APIs. */
@Composable
fun ChipRow(modifier: Modifier = Modifier, content: @Composable RowScope.() -> Unit) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(Dimens.spaceSm),
        content = content
    )
}
